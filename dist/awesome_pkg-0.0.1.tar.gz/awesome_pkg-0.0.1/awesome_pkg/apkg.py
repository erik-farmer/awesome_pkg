def main():
    print('Hey this is the latest version')
