def main():
    print('Hey this is the 0.0.2 version')
